﻿namespace ChatApp
{
    public interface IMessageSource
    {
    }
}